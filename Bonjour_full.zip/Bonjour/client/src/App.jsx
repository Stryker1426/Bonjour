// Full frontend placeholder
export default function App(){ return <div>OWNED - Full Frontend</div> }