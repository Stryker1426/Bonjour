import React from 'react';

export default function App(){
  return <div style={{background:'black',color:'white',height:'100vh'}}>
    <h1>OWNED</h1>
    <p>Categories: Men, Women, Kids</p>
  </div>;
}