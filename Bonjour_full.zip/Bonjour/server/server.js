// Full backend placeholder with Stripe + suppliers
console.log('Backend running');